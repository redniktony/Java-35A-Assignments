Store Data Reader
������������������������
This program reads the data from the text file and put in an 2 dimensional array.
I created the interface for selection to let user choose which kind of information they want and which shop they want to calculate.
As the assignment requires:

The total sales for each week. (Should print 5 values - one for each week).
The average daily sales for each week. (Should print 5 values - one for each week).
The total sales for all the weeks. (Should print 1 value)
The average weekly sales. (Should print 1 value)
The week with the highest amount in sales. (Should print 1 week #)
The week with the lowest amount in sales. (Should print 1 week #)

Also prints the data into the screen.
