Object relationship And File IO
This program use different packages to reorder the data information of each students.
Maximum 40 students. 

The input is to be read from a text file. (score.txt)