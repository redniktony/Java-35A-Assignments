The code is based on the Lab5 codes
Difference is create a separate serialized file using ObjectOutputStream for each student.
HuaXia