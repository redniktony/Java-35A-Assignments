package lab2;

//Hua Xia
//CIS 35A 
//Assignment 6
//Due Date: June 6
//Submit Date: June 10
interface Inter {
	// from Student class
	void printSID();
	void printScores();
	// from Stats class
	void findlow(Grade[] a);
	void findhigh(Grade[] a);
	void findavg(Grade[] a);

}