Coin Toss
This game is to Toss a coin. The main function is in the game.java
Type how many times you need to toss. Then the result will print to the screen.
Enjoy.
