Personal Information
Collecting the personal information, by typing how many people you need to record, then step by step type in name address age and phone number. At last the collected data will print to the screen.
